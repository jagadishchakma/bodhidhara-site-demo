<?php
   define('SERVER', 'localhost');
   define('USERNAME', 'JAGADISH');
   define('PASSWORD', 'o[4[&d@We#Y?');
   define('DATABASE', 'bodhidha_bodhidhara');
   $conn = mysqli_connect(SERVER,USERNAME,PASSWORD,DATABASE);
?>